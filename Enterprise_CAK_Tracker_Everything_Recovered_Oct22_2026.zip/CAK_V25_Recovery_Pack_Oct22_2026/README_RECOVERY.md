# Enterprise CAK Tracker — Recovery Pack (October 22, 2026)

## Important status

This pack preserves the recoverable files that were available in the conversation. It is **not confirmed to be a complete copy of the final live application from the end of October 21 / early October 22**.

The W3Schools terminal later showed a reset-looking `version.json` (`0.1`), and its active template was missing the recently installed features. The terminal's `v25-backup` directory was also absent. The original terminal backups named `pre-driver-report-20261022-013457`, `pre-theme-quiz-20261022-021603`, and `pre-darth-haas-quiz-20261022-023714` were reported in terminal output, but their files were not available in the reset environment.

## What is included

- `Recovered_Originals/CAK_Tracker_V25_Nightly_Test_Build.zip` — full earlier V25 Django project snapshot.
- `Recovered_Originals/Enterprise_CAK_Tracker_Modern_Navy_Redesign_Fast_Parking_No_Occupancy_Checks.zip` — a later redesign package, including a full HTML template.
- `Recovered_Originals/CAK_Admin_Vehicle_History_Integration_Pack.zip` and `Admin_Vehicle_History_Search_Example.zip` — admin history integration/example files.
- `Recovered_Originals/static-snapshot.zip` — earlier static project snapshot.
- `Recovered_Originals/index(2).html` — an earlier full template from the conversation.
- `Recovered_Originals/index.html` — an admin-history example template, not the whole live app.

## Features known from terminal output to have been installed before the reset

The terminal confirmed a successful patch and checks for:
- Driver report driver selector, print/PDF, and TXT report controls.
- Admin vehicle search/history.
- Fuel slider and mileage controls.
- Dustin's Drop Closeout Queue.
- Personalized theme quizzes and welcome messages:
  - E44DGY — Harry Potter / “Welcome Headmaster Blake”
  - E36C9C — The Clone Wars / “Welcome Master Jedi Sean”
  - E327RP — Darth Vader / “Welcome Darth Haas”
- VIN OCR confirmation prompt removal.

The available original snapshots do **not** contain all of these latest changes. This pack includes the recoverable source material and does not falsely claim that all final edits were reconstructed.

## Safe recovery instructions

1. Keep the current W3Schools Space untouched for now.
2. Download and extract `CAK_Tracker_V25_Nightly_Test_Build.zip` locally as the baseline full Django project.
3. Compare the later redesign ZIP's `blank/templates/index.html` with the baseline template.
4. Before deploying, back up the current database file and confirm its actual path in the W3Schools persistent storage. Do not replace the database with a blank copy.
5. Reapply the missing final changes to the recovered template, then run `python3 manage.py check` and verify the report, mileage, fuel slider, drop queue, and quiz flows before deployment.

## Do not

- Do not upload this recovery pack directly over the live Space.
- Do not replace the existing database with a database from an old ZIP.
- Do not assume that a successful Django system check proves that every browser feature works.

## Artifact integrity

See `manifest.json` for file sizes and SHA-256 checksums of the recovered artifacts.
