CAK Tracker V23 - live scanners and usability updates

BACK UP YOUR LIVE W3SCHOOLS PROJECT FIRST.

For this update replace these files in your existing W3Schools project:
- blank/templates/index.html
- blank/views.py (only if your current server does not already have the employee removal endpoint)

Do NOT overwrite /home/app/w3s-dynamic-storage/database.db or .env.
Do NOT delete the existing /home/app directory.

Added: separate live VIN and QR camera buttons, automatic captured camera photo on successful read, last 8/last 11/full 17 manual VIN entry, duplicate warning, occupied spot warning, audible/vibration success feedback (browser permitting), optional reopen scanner after save, flashlight and zoom where browser camera permits, search and occupancy view retained, employee deactivation with protected history retained.

Known limits: Full VIN is needed for reliable public VIN decoding. QR codes without a VIN or recognized identifier cannot be resolved without authorized fleet data. On iPhone Safari, camera permission and HTTPS are required. The browser may not support torch, zoom, vibration, or BarcodeDetector; the app attempts a ZXing fallback. Network is required for third-party barcode library and NHTSA decoding. The scanner needs live device testing before operational use. A successful scan captures the full camera frame, not a tightly cropped barcode.
