# CAK Team Parking Tracker — shared server edition

This edition keeps the step-by-step photo tracker and adds persistent shared employee accounts.

## Running it

1. Install Python 3.11 or newer.
2. In this folder, run `python -m pip install -r requirements.txt`.
3. Administrator login defaults to `EAdmin` with password `admin` for local testing. For real deployment, change it using the environment setting:
   - PowerShell: `$env:CAK_ADMIN_PASSWORD="change-this-to-a-strong-password"`
   - macOS/Linux: `export CAK_ADMIN_PASSWORD='change-this-to-a-strong-password'`
4. For local testing only, set `CAK_INSECURE_HTTP=1`. **Do not set this when published online.**
5. Run `python -m uvicorn server:app --host 127.0.0.1 --port 8000` and visit `http://127.0.0.1:8000`.
6. Sign in as `EAdmin` with the configured password (`admin` for local testing), and create E-number employee accounts. Employees sign in with their E-number only.

## Using across employee phones

This needs a trusted HTTPS hosting service (not a downloaded HTML file). Deploy this folder to a Python-capable HTTPS host, set `CAK_ADMIN_PASSWORD` in hosting secrets, and use durable persistent storage for `CAK_DATA_DIR`. Share the one secured URL with employees. The server creates `data/cak.sqlite3`, including photos; **back up this directory frequently**. Make sure HTTPS and appropriate staff data policies are enforced before real use.

EAdmin can review all saved records, including the employee E-number on records and end-of-day reports. Employees can view their own records after login. Logging out does not erase server records.

## Important limitations

- This server package is not deployed online. Other phones cannot sync until the server is hosted and reachable by them.
- Existing photos stored in older local-only versions do not automatically transfer into the server. Keep those files/browser storage until you have safely migrated or exported them.
- Employee login uses E-number only, so it does **not** authenticate employee identity. Anyone with a valid E-number can access that employee's records. Administrator accounts still require a password; default `admin` is insecure. Change the admin password and have your organization approve this access model before using real employee or vehicle records.
- This is a prototype requiring proper production configuration, HTTPS, backup procedures, access controls, and a security review before deployment with real Enterprise vehicle information.
