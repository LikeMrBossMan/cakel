"""CAK team tracker demo server. Host only behind HTTPS, with regular backups."""
import os, sqlite3, secrets, hashlib, hmac, json, time, re
from pathlib import Path
from contextlib import contextmanager
from fastapi import FastAPI, Request, HTTPException, UploadFile, File, Form
from fastapi.responses import FileResponse, Response
from pydantic import BaseModel

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('CAK_DATA_DIR',str(ROOT/'data')))
DATA.mkdir(parents=True,exist_ok=True)
DB=DATA/'cak.sqlite3'
MAX_PHOTO=12*1024*1024
ADMIN_PW=os.environ.get('CAK_ADMIN_PASSWORD','admin')  # Change this before any public deployment.

def hashpw(pw):
 salt=os.urandom(16); h=hashlib.scrypt(pw.encode(),salt=salt,n=2**14,r=8,p=1); return salt.hex()+':'+h.hex()
def verify(pw,stored):
 try:
  salt,h=stored.split(':'); check=hashlib.scrypt(pw.encode(),salt=bytes.fromhex(salt),n=2**14,r=8,p=1)
  return hmac.compare_digest(check,bytes.fromhex(h))
 except Exception:return False
@contextmanager
def conn():
 db=sqlite3.connect(DB,timeout=20);db.row_factory=sqlite3.Row;db.execute('PRAGMA foreign_keys=ON');db.execute('PRAGMA busy_timeout=20000')
 try:yield db;db.commit()
 finally:db.close()
with conn() as c:
 c.execute('PRAGMA journal_mode=WAL')
 c.execute('CREATE TABLE IF NOT EXISTS employees (eno TEXT PRIMARY KEY,password TEXT NOT NULL,display_name TEXT NOT NULL,enabled INTEGER NOT NULL DEFAULT 1,admin INTEGER NOT NULL DEFAULT 0)')
 c.execute('CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY,eno TEXT NOT NULL,expiry INTEGER NOT NULL,FOREIGN KEY(eno) REFERENCES employees(eno))')
 c.execute('CREATE TABLE IF NOT EXISTS vehicles (id TEXT PRIMARY KEY,eno TEXT NOT NULL,details TEXT NOT NULL,photo BLOB,photo_type TEXT,FOREIGN KEY(eno) REFERENCES employees(eno))')
 c.execute('INSERT OR IGNORE INTO employees (eno,password,display_name,enabled,admin) VALUES (?,?,?,?,?)',('EAdmin',hashpw(ADMIN_PW),'Administrator',1,1))
 # Admin password configured with environment, changes take effect on restart.
 c.execute('UPDATE employees SET password=? WHERE eno=?',(hashpw(ADMIN_PW),'EAdmin'))
app=FastAPI(title='Enterprise CAK Team Tracker')
class Login(BaseModel): eno:str; password:str = ''
class Employee(BaseModel): eno:str; name:str

def require(req,admin=False):
 token=req.cookies.get('cak_session',''); th=hashlib.sha256(token.encode()).hexdigest()
 with conn() as c:
  row=c.execute('SELECT e.* FROM sessions s JOIN employees e ON e.eno=s.eno WHERE s.token_hash=? AND s.expiry>? AND e.enabled=1',(th,int(time.time()))).fetchone()
 if row is None or (admin and not row['admin']):raise HTTPException(401 if row is None else 403,'Login required' if row is None else 'Administrator only')
 return row
@app.get('/')
def home():return FileResponse(ROOT/'index.html',media_type='text/html')
@app.post('/api/login')
def login(info:Login):
 with conn() as c: user=c.execute('SELECT * FROM employees WHERE eno=? AND enabled=1',(info.eno.strip(),)).fetchone()
 if not user or (user['admin'] and not verify(info.password,user['password'])):raise HTTPException(401,'Invalid E-number or administrator password')
 token=secrets.token_urlsafe(40)
 with conn() as c:c.execute('INSERT INTO sessions VALUES (?,?,?)',(hashlib.sha256(token.encode()).hexdigest(),user['eno'],int(time.time())+86400*14))
 r=Response(content=json.dumps({'eno':user['eno'],'name':user['display_name'],'admin':bool(user['admin'])}),media_type='application/json')
 r.set_cookie('cak_session',token,httponly=True,secure=os.environ.get('CAK_INSECURE_HTTP')!='1',samesite='lax',max_age=86400*14,path='/')
 return r
@app.post('/api/logout')
def logout(req:Request):
 token=req.cookies.get('cak_session','')
 with conn() as c:c.execute('DELETE FROM sessions WHERE token_hash=?',(hashlib.sha256(token.encode()).hexdigest(),))
 r=Response(content='{}',media_type='application/json');r.delete_cookie('cak_session',path='/');return r
@app.get('/api/me')
def me(req:Request):
 u=require(req);return {'eno':u['eno'],'name':u['display_name'],'admin':bool(u['admin'])}
@app.get('/api/employees')
def employees(req:Request):
 require(req,True)
 with conn() as c:return [{'eno':r['eno'],'name':r['display_name'],'enabled':bool(r['enabled']),'admin':bool(r['admin'])} for r in c.execute('SELECT * FROM employees ORDER BY eno')]
@app.post('/api/employees')
def add_employee(req:Request,info:Employee):
 require(req,True);eno=info.eno.strip().upper()
 if not re.fullmatch(r'E[A-Z0-9]{2,20}',eno) or eno=='EADMIN' or not info.name.strip():raise HTTPException(400,'Use a valid E-number and employee name')
 with conn() as c:
  try:c.execute('INSERT INTO employees VALUES (?,?,?,1,0)',(eno,'',info.name.strip()))
  except sqlite3.IntegrityError:raise HTTPException(409,'Employee already exists')
 return {'ok':True}
@app.get('/api/records')
def list_records(req:Request):
 u=require(req)
 with conn() as c:
  rows=c.execute('SELECT id,eno,details FROM vehicles ORDER BY rowid DESC' if u['admin'] else 'SELECT id,eno,details FROM vehicles WHERE eno=? ORDER BY rowid DESC',() if u['admin'] else (u['eno'],)).fetchall()
 result=[]
 for r in rows:
  d=json.loads(r['details']);d['id']=r['id'];d['employee']=r['eno'];result.append(d)
 return result
@app.get('/api/photos/{id}')
def photo(req:Request,id:str):
 u=require(req)
 with conn() as c:r=c.execute('SELECT eno,photo,photo_type FROM vehicles WHERE id=?',(id,)).fetchone()
 if not r or (r['eno']!=u['eno'] and not u['admin']):raise HTTPException(404,'Photo not found')
 return Response(content=r['photo'] or b'',media_type=r['photo_type'] or 'image/jpeg')
@app.post('/api/records')
async def save_record(req:Request,details:str=Form(...),photo:UploadFile=File(...)):
 u=require(req)
 try:d=json.loads(details)
 except:raise HTTPException(400,'Invalid record')
 id=str(d.get('id',''))
 if not re.fullmatch(r'[a-zA-Z0-9_-]{5,100}',id):raise HTTPException(400,'Invalid ID')
 if d.get('folder') not in ('Clean Parking','Down to Washbay'):raise HTTPException(400,'Invalid folder')
 data=await photo.read(MAX_PHOTO+1)
 if len(data)>MAX_PHOTO or not data:raise HTTPException(413,'Photo must be under 12 MB')
 if photo.content_type not in ('image/jpeg','image/png','image/webp','image/heic','image/heif'):raise HTTPException(415,'Unsupported image type')
 d.pop('blob',None);d.pop('employee',None)
 with conn() as c:
  existing=c.execute('SELECT eno FROM vehicles WHERE id=?',(id,)).fetchone()
  if existing and existing['eno']!=u['eno'] and not u['admin']:raise HTTPException(403,'Record belongs to a different employee')
  owner=existing['eno'] if existing else u['eno']
  c.execute('INSERT OR REPLACE INTO vehicles VALUES (?,?,?,?,?)',(id,owner,json.dumps(d),data,photo.content_type))
 return {'ok':True}
@app.delete('/api/records/{id}')
def delete_record(req:Request,id:str):
 u=require(req)
 with conn() as c:
  r=c.execute('SELECT eno FROM vehicles WHERE id=?',(id,)).fetchone()
  if not r:raise HTTPException(404,'Not found')
  if r['eno']!=u['eno'] and not u['admin']:raise HTTPException(403,'Not your record')
  c.execute('DELETE FROM vehicles WHERE id=?',(id,))
 return {'ok':True}
