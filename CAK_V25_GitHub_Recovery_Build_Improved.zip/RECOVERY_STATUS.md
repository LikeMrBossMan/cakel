# CAK V25 GitHub recovery candidate

Built from the complete Enterprise CAK Tracker V23 Django project, with the newer V25 redesign HTML as the interface starting point and a reconstructed personalized triple-tap Easter egg quiz.

Personalized themes:
- E44DGY — Harry Potter — Welcome Headmaster Blake
- E327RP — Darth Vader — Welcome Darth Haas
- E36C9C — The Clone Wars — Welcome Master Jedi Sean

The newer UI template retains its mileage control. This package is a recovery candidate, not a verified production replacement. The final driver report/date selector, fuel slider, admin vehicle search, and Drop Closeout Queue are not confirmed restored in this build. Do not deploy over the live app until those features and the Django integration are tested. No production database is included or modified.
