CAK Tracker V25 Nightly — deployment guide

IMPORTANT: This is a test build, not yet deployed to your W3Schools Space.
Back up your live project and persistent database before installing.

On your existing W3Schools Django Space, update only these application files:
- blank/templates/index.html
- blank/views.py (if your live copy lacks employee deactivation)
- version.json (optional)

Do NOT overwrite or delete:
- /home/app/w3s-dynamic-storage/database.db
- /home/app/w3s-dynamic-storage/.env

Do not replace the entire /home/app folder or run a database reset.
Restart the app, sign in, and verify records and accounts before operational use.

Test on a real iPhone with HTTPS and camera permission: live VIN/QR, fallback scanning, photo capture, save, occupied-spot warnings, and employee removal. Camera flashlight, zoom, and vibration depend on browser support. Full 17-character VINs can be decoded via NHTSA; partial VINs cannot reliably be decoded unless matched with existing records. Scanner libraries require internet access.
